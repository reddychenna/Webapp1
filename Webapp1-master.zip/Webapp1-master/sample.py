import webbrowser
webbrowser.open('http://localhost:4000', new=2)
print "This is the first line of test program"


