class  MyPrg1{
 public static void main(String args[]){
     int a = 100;
     System.out.println("Hello World from a git Hub 1........"+a);
     System.out.println("Hello World from a git Hub 2");
     System.out.println("12 New change added to the Java program");
     System.out.println("Change added to trigger a SCM polled job");
 }
}
