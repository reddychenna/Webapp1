touch file.txt
echo "This is a new file created with additional comments" >> fileNew.txt
cp fileNew.txt copiedfromScript1.txt
